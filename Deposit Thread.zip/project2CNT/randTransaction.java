/* Name: James Rock
 Course: CNT 4714 – Fall 2019
 Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
 Date: Sunday October 6, 2019
*/

package project2;

/**
  @author james
 */

import java.util.Random;
public class randTransaction 
    {
    
	 //make int within range
	 private static int intRange(int min, int max)
	    {
       Random randGen = new Random();
       int j = 0;

     //loop till random number in range
       while (min >= j || max <= j) 
          {
          j = randGen.nextInt();
       }
       return j;
    }
    
	 //take boolean-operator and output random number
	  
      public static int newNumber (boolean op){
    
       //random amount
       int randAmt = 0;

       //if deposit true
          if (op == true){
          randAmt = intRange(1, 200); 
          return randAmt;

        //if withdrawing
              } 
            else 
              {
           randAmt = intRange(1, 50);
           return randAmt;
       }
    }
    
     //generate-random sleep time for thread
     public static int newSleepTime(boolean op) 
       {
       Random randGen = new Random();
        int sleepTime;
        
       //if deposit true
       if (op == true)
          {
          sleepTime = randGen.nextInt(100);
          return sleepTime;

      //if withdrawing
           } 
          else  
            {
          sleepTime = randGen.nextInt(8);
           return sleepTime;
       }
       } }