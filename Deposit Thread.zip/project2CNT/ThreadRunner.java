/* Name: James Rock
 Course: CNT 4714 – Fall 2019
 Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
 Date: Sunday October 6, 2019
*/

   package project2;
   public class ThreadRunner {
    
	public static void main(String[] args)
	
	   {
        
       //create bank account
       Account acc = new Account();

       //base output
       System.out.printf("Deposit Threads\t\t\tWithdrawl Threads\t\tBalence\t\t\t\n");
       System.out.printf("---------------\t\t\t-----------------\t\t---------------\t\t\t\n");  

       //setup thread types
       depositThread deposit = new depositThread(acc);
       withdrawlThread withdrawl = new withdrawlThread(acc);        

       //initalizing of thread
       Thread deposit1 = new Thread(deposit, "D1");
       Thread deposit2 = new Thread(deposit, "D2");
       Thread deposit3 = new Thread(deposit, "D3");
       Thread deposit4 = new Thread(deposit, "D4");
            
       Thread wd1 = new Thread(withdrawl, "W1");
       Thread wd2 = new Thread(withdrawl, "W2");
       Thread wd3 = new Thread(withdrawl, "W3");
       Thread wd4 = new Thread(withdrawl, "W4");
       Thread wd5 = new Thread(withdrawl, "W5");
       Thread wd6 = new Thread(withdrawl, "W6");
       Thread wd7 = new Thread(withdrawl, "W7");
       Thread wd8 = new Thread(withdrawl, "W8");
        
      //start thread
       deposit1.start();
       wd1.start();
       deposit2.start();
       wd2.start();
       wd3.start();
       wd7.start();
       wd8.start();
       wd4.start();
       wd5.start();
       deposit3.start();
       deposit4.start();
       wd5.start();
       wd6.start();
        
       } }