/* Name: James Rock
 Course: CNT 4714 – Fall 2019
 Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
 Date: Sunday October 6, 2019
*/

package project2;

//run loops for deposit-thread

public class depositThread implements Runnable 
    {
    private Account acc;

    //constructor link-thread and main account
     public depositThread (Account mainAcc) 
       {
       acc = mainAcc;
        }

      public void run() 
      {
    try 
     {
         
	  //infinite-loop
      while (true)
         {
           acc.deposit();
           Thread.sleep(7500);
           }
      }
 
 catch (InterruptedException e) 
   {
  e.printStackTrace();
   }
 } }