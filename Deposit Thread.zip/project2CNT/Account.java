/* Name: James Rock
 Course: CNT 4714 – Fall 2019
 Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
 Date: Sunday October 6, 2019
*/
package project2;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

//Account
public class Account 
    {
  private int balance;
  private Lock accessLock;
  private Condition sufficientFunds;

    //construcutor setup account with locking-system
    public Account() 
       {
     balance = 0;
     accessLock = new ReentrantLock();
     sufficientFunds = accessLock.newCondition(); }

     //locking system handledeposit
     public void deposit() throws InterruptedException{
      int add = randTransaction.newNumber(true);
      accessLock.lock();
      try 
        {
        balance += add;
        System.out.printf("Thread %s deposits $%-3d\t\t\t\t\t\tBalence is $%-3d\n", Thread.currentThread().getName(), add, balance);
        sufficientFunds.signalAll();
         } 
        finally 
          {
         accessLock.unlock();
      }
    }

   //locking-system handle withdrawl
  public void withdrawl() throws InterruptedException 
    {
   int sub = randTransaction.newNumber(false);
   accessLock.lock();
    try 
     {
           
	 //if funds transactions
       if (balance > sub) 
          {
           balance -= sub;
           System.out.printf("\t\t\t\tThread %s withdrawls $%-3d\tBalence is $%-3d\n", Thread.currentThread().getName(), sub, balance);   
         }
            
       //if insufficient funds wait for deposit before trys again
        else 
          {
         while (balance < sub) 
           {
            System.out.printf("\t\t\t\tThread %s withdrawls $%-3d\tWithdrawl - Blocked - Insufficient Funds\n", Thread.currentThread().getName(), sub);
            sufficientFunds.await();
           }
         }    
         } 
  
   catch (InterruptedException e) 
   {
    e.printStackTrace();
     } 
     finally 
     {
      accessLock.unlock();
    }
  } }