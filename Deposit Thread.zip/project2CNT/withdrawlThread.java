/* Name: James Rock
 Course: CNT 4714 – Fall 2019
 Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
 Date: Sunday October 6, 2019
*/

package project2;
//loop withdrawl-thread
public class withdrawlThread implements Runnable 
     {
    
private Account acc;

  //constructor-thread to main account
   public withdrawlThread (Account accMain) 
      {
        acc = accMain;
       }

   public void run() 
      {
       try 
      {
    //infinite-loop
          while (true) 
            {
              acc.withdrawl();
              Thread.sleep(5);
              }
           }
        catch (InterruptedException e) 
          {
             e.printStackTrace();
           }
   }  }
